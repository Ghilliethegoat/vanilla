package net.minecraft.client.renderer.block.statemap;

import java.util.Map;
import net.minecraft.block.Block;

public interface IStateMapper
{
    Map func_178130_a(Block p_178130_1_);
}
